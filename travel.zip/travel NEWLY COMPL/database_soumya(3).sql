-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 26, 2017 at 05:40 PM
-- Server version: 5.7.18-0ubuntu0.16.04.1
-- PHP Version: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_soumya`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `book_isbn` int(11) NOT NULL,
  `book_title` varchar(50) NOT NULL,
  `book_author` varchar(50) NOT NULL,
  `book_category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `book_isbn`, `book_title`, `book_author`, `book_category`) VALUES
(2, 7893, 'Laravel Tiger', 'Mutafaf', 'Programming'),
(3, 8934, 'Android Programming', 'Farrukh', 'Programming'),
(6, 8902, 'Intro to Psychology', 'Ayesha', 'Psychology'),
(7, 2345, 'Calculus-1', 'John doe', 'Math'),
(8, 8927, 'Chemistry Part-1', 'Aliza Mam', 'Chemistry'),
(9, 6723, 'Math Part-1', 'Sir Sohail Amanat', 'Math'),
(10, 0, 'titttttttttttle', 'tttttttttttttttt', 'cfewfergrtfg');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `exid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `exname` varchar(100) NOT NULL,
  `exdate` varchar(20) NOT NULL,
  `exprice` int(11) NOT NULL,
  `exattach` varchar(200) NOT NULL,
  `exstatus` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`exid`, `uid`, `tid`, `exname`, `exdate`, `exprice`, `exattach`, `exstatus`) VALUES
(1, 1, 8, 'lunchkkkk', '21-09-2017', 200, 'esffsd', 'accepted'),
(2, 4, 8, 'bus charge', '30-05-2017', 800, 'fergerfver', 'rejected'),
(3, 1, 8, 'auto charge & bus charge', '20-09-2017', 100, '45', 'accepted'),
(4, 1, 8, 'snacks', '12-09-2017', 45, 'image', 'rejected'),
(5, 4, 5, 'room rent', '12-21-2019', 300, 'fsdfd', 'accepted'),
(6, 1, 5, 'extraaa', '23-09-2019', 344, 'dgfdgvfd', 'rejected'),
(7, 1, 5, 'dinner', '23-09-2098', 400, 'rdgdfgf', 'accepted'),
(8, 1, 8, 'coffee', '23-09-2000', 400, 'ergregrg', 'rejected'),
(9, 1, 8, 'maggiee', '20--09-2013', 5, 'dgg', 'rejected'),
(10, 1, 5, 'hh', '34324', 3434, 'gvf', 'rejected'),
(11, 1, 5, 'juice', '23-09-2109', 34, 'wddd', 'accepted'),
(12, 1, 8, 'juicekkk', '4-09-4049', 1000, 'fedcfsd', 'rejected'),
(13, 1, 5, 'hhh', '785', 700, 'jmhjmjuymu', 'accepted'),
(14, 5, 11, '', '', 0, '', 'pending'),
(15, 7, 11, '', '', 0, '', 'pending'),
(16, 7, 12, '', '', 0, '', 'pending'),
(17, 1, 15, '', '', 0, '', 'pending'),
(18, 1, 19, '', '', 0, '', 'pending'),
(19, 1, 19, 'gggg', '45-009786', 677777, 'vcfbxgb', 'pending'),
(20, 1, 5, 'cbv', 'rgdf', 800, 'sfr', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `text`) VALUES
(2, 'What is Code Ignitor?', 'what-is-code-ignitor', 'CodeIgnitor is Framework.drgdfgbfbfcbcvxdf'),
(4, 'sss', 'sss', 'ssssssssssssssssss');

-- --------------------------------------------------------

--
-- Table structure for table `travel`
--

CREATE TABLE `travel` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `tname` varchar(100) NOT NULL,
  `tdesc` varchar(1000) NOT NULL,
  `tstartd` varchar(30) NOT NULL,
  `tendd` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'ongoing'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `travel`
--

INSERT INTO `travel` (`tid`, `uid`, `tname`, `tdesc`, `tstartd`, `tendd`, `status`) VALUES
(1, 1, 'recruitment', 'R D in banagaluru', '12-03-2017', '13-03-2017', '0'),
(5, 1, 'travel4', 'desc44', '12-12-2012', '13-12-2012', '0'),
(8, 1, 'chikkamangaluru', 'training', '12-09-2019', '13-10-2019', '0'),
(9, 5, 'hubli', 'recruitment', '45-09-2019', '46-09-2019', ''),
(10, 5, 'huuuuu', 'gggggg', '45-09-5079', '45-09-8778', ''),
(11, 5, 'kkkk', 'kkkk', '45-09-8009', '45-09-8009', 'ongoing'),
(12, 7, 'mmm', ',mmmmm', '3254345', '435645t6', 'ongoing'),
(13, 7, 'travel11', 'cjhgjwgy', 'b,jhghk', 'hkgi', 'ongoing'),
(14, 7, 'fg', 'ghgf', '125', '254', 'ongoing'),
(15, 7, 'f', 'rfrf', 'df', 'asdf', 'ongoing'),
(16, 1, 'dfgg', 'dfgvdf', 'fg', 'fsd', 'ongoing'),
(17, 7, 'ter', 'hgt', '655', '45', 'ongoing'),
(18, 1, 'gdf', 'sdfgvd', 'rg', 'dfgdf', 'ongoing'),
(19, 1, 'h', 'h', 'fgh', 'hyh', 'ongoing');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `ufname` varchar(30) NOT NULL,
  `ulname` varchar(30) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `upassword` varchar(10) NOT NULL,
  `urole` varchar(20) NOT NULL,
  `udept` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `ufname`, `ulname`, `uemail`, `upassword`, `urole`, `udept`) VALUES
(1, 'Soumya', 'Shet', 'soumyashet95@gmail.com', 'soumya1234', 'employee', 'development'),
(2, 'sahana', 'kulkarni', 'sahana@gmail.com', 'sahana123', 'manager', 'design'),
(5, 'deepa', 'k', 'deepa@gmail.com', 'deepa123', 'employee', 'design'),
(6, 'renu', 'jj', 'renu@gmail.com', 'renu123', 'employee', 'design'),
(7, 'Nikhil', 'r', 'nikhil@gmail.com', 'nikhil123', 'employee', 'design');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`exid`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`);

--
-- Indexes for table `travel`
--
ALTER TABLE `travel`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `exid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `travel`
--
ALTER TABLE `travel`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
