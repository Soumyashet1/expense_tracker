<div class="container">
  <h3>Expenses of Travel</h3>
  <br />
  <br />
  <a href="<?php echo base_url('/index.php/admin')?>"><button class="btn btn-primary" onclick="">BACK</button></a>
  <br />  <br />  <br />
  <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Expense Id</th>
        <th>Expense Name</th>
        <th>Expense_Date</th>
        <th>Expense Price</th>
        <th>Expense_attachment</th>
        <th>Expense_status</th>
        <th style="width:125px;">Action
        </p></th>
      </tr>
    </thead>
    <tbody>

      <?php foreach($data1 as $usr){?>
           <tr>
               <td><?php echo $usr->exid;?></td>
              <td><?php echo $usr->exname;?></td>
              <td><?php echo $usr->exdate;?></td>
              <td><?php echo $usr->exprice;?></td>
              <td><?php echo $usr->exattach;?></td>
              <td><?php echo $usr->exstatus;?></td>
              <td><?php $td= $usr->tid;?>
                <button class="btn btn-primary" onclick="edit_status_to_accepted(<?php echo $usr->exid;?>)"><i class="glyphicon glyphicon-ok"></i></button>
                <button class="btn btn-primary" onclick="edit_status_to_rejected(<?php echo $usr->exid;?>)"><i class="glyphicon glyphicon-remove"></i></button>
                <!--<a href=" href="<?php echo base_url ('/index.php/admin/each_t_expense/'.$usr->exid.'')?>"">
                  <img src="<?php echo base_url();?>assests/assets/images/a.jpg" style="width: 32%;"></a>
                <a href=" href="<?php echo base_url ('/index.php/admin/each_t_expense/'.$usr->exid.'')?>"">
                  <img href=""src="<?php echo base_url();?>assests/assets/images/r.jpg" style="width: 32%;"></a>-->
                </td>
            </tr>
           <?php }?>
    </tbody>
    <tfoot>
      <tr>
        <th>Expense Id</th>
        <th>Expense Name</th>
        <th>Expense_Date</th>
        <th>Expense Price</th>
        <th>Expense_attachment</th>
        <th>Expense_status</th>
        <th style="width:125px;">Action
        </p></th>
      </tr>
    </tfoot>
  </table>
</div>
<script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
<script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
} );
  var save_method; //for save method string
  var table;
  function edit_status_to_accepted(id)
  {
      // ajax edits data from database
        $.ajax({
          url : "<?php echo site_url('index.php/admin/edit_exp_accepted')?>/"+id,
          type: "POST",
          dataType: "JSON",
          success: function(data)
          {
             location.reload();
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error deleting data');
          }
      });
  }
  function edit_status_to_rejected(id)
  {
      // ajax edits data from database
        $.ajax({
          url : "<?php echo site_url('index.php/admin/edit_exp_rejected')?>/"+id,
          type: "POST",
          dataType: "JSON",
          success: function(data)
          {
             location.reload();
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error deleting data');
          }
      });
  }
</script>
</body>
</html>
