<div class="container">
  <h1>TRAVELS</h1>
  <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Travel Id</th>
        <th>Travel name</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($data1 as $usr){?>
           <tr>
               <td><?php echo $usr->tid;?></td>
               <td><a href="<?php echo base_url ('/index.php/expense/userexpense/'.$usr->tid.'')?>"><?php echo $usr->tname;?></a></td>
               <td><?php echo $usr->price;?></td>
            </tr>
           <?php }?>
    </tbody>
    <tfoot>
      <tr>
        <th>Travel Id</th>
        <th>Travel name</th>
        <th>Price</th>
      </tr>
    </tfoot>
  </table>
</div>
</body>
</html>
