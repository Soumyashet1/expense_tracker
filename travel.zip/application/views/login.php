<!DOCTYPE html>
<html>
<head>
<title>Expense Tracker</title>
<link href="<?php echo base_url(); ?>assests/assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
<script src="<?php echo base_url(); ?>assests/assets/js/jquery-1.9.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assests/assets/css/easy-responsive-tabs.css" />
<link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
</head>
<body class="bg agileinfo">
   <h1 class="agile_head text-center"></h1>
   <div class="w3layouts_main wrap">
        <div id="parentHorizontalTab_agile">
            <ul class="resp-tabs-list hor_1">
                <li>LogIn</li>
               <!--<li>SignUp</li>-->
            </ul>
            <div class="resp-tabs-container hor_1">
               <div class="w3_agile_login">
                    <form action="#" method="post" class="agile_form">
					   <p>Email</p><input type="email" name="email" required="required" />
					   <p>Password</p><input type="password" name="pass" required="required" class="password" />
					  <input type="submit" value="LogIn" class="agileinfo" />
                      </form>
					 <div class="login_w3ls">
							<a href="#">Forgot Password</a>
					 </div>
                </div>
              </div>
        </div>
   </div>
<script src="<?php echo base_url(); ?>assests/assets/js/easyResponsiveTabs.js"></script>
<script type="text/javascript">
$(document).ready(function() {
//Horizontal Tab
$('#parentHorizontalTab_agile').easyResponsiveTabs({
type: 'default', //Types: default, vertical, accordion
width: 'auto', //auto or any width like 600px
fit: true, // 100% fit in a container
tabidentify: 'hor_1', // The tab groups identifier
activate: function(event) { // Callback function if tab is switched
var $tab = $(this);
var $info = $('#nested-tabInfo');
var $name = $('span', $info);
$name.text($tab.text());
$info.show();
}
});
});
</script>
</body>
</html>
