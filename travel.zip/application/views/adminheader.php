<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Learn PHP CodeIgniter Framework with AJAX and Bootstrap</title>
    <link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assests/bootstrap/css/style1.css')?>" rel="stylesheet">
    </head>
  <body>
<nav class="navbar navbar-default" style="background-color: #800042;
border-color: #FFF;min-height: 90px;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">
        <img alt="Brand" src="<?php echo base_url(); ?>assests/assets/images/LOGO.png" style="width: 60%;">
      </a>
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1"style="margin-top: 17px;font-size: 21px;">
      <ul class="nav navbar-nav navbar-right" style="color: #fff;">
        <li><a style="color: #fff;" href="<?php echo base_url('/index.php/admin')?>" >Expenses</a></li>
        <li><a style="color: #fff;" href="<?php echo base_url('/index.php/user')?>">Users</a></li>
        <li><a style="color: #fff;" href="<?php echo base_url('/index.php/travel')?>">Travel</a></li>
        <li><a style="color: #fff;" href="<?php echo base_url('/index.php/login/loginpage')?>">Logout</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
