  <div class="container">
    <h1>USERS</h1>
</center>
    <br />
    <button class="btn btn-success" onclick="add_user()"><i class="glyphicon glyphicon-plus"></i> Add User</button>
    <br />
    <br />
    <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
					<th>User Id</th>
					<th>User First Name</th>
          <th>User Last Name</th>
					<th>User E-mail-Id</th>
					<th>User Password</th>
          <th>Role</th>
          <th>Department</th>
          <th style="width:125px;">Action
          </p></th>
        </tr>
      </thead>
      <tbody>
				<?php foreach($user as $usr){?>
				     <tr>
				         <td><?php echo $usr->uid;?></td>
				         <td><?php echo $usr->ufname;?></td>
								 <td><?php echo $usr->ulname;?></td>
								<td><?php echo $usr->uemail;?></td>
								<td><?php echo $usr->upassword;?></td>
                <td><?php echo $usr->urole;?></td>
                <td><?php echo $usr->udept;?></td>
								<td>
									<button class="btn btn-warning" onclick="edit_user(<?php echo $usr->uid;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
									<button class="btn btn-danger" onclick="delete_user(<?php echo $usr->uid;?>)"><i class="glyphicon glyphicon-remove"></i></button>
								</td>
				      </tr>
				     <?php }?>
      </tbody>
      </table>
  </div>
  <script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
  <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;
    function add_user()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }
    function edit_user(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals
      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('index.php/user/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
           $('[name="uid"]').val(data.uid);
            $('[name="ufname"]').val(data.ufname);
            $('[name="ulname"]').val(data.ulname);
            $('[name="uemail"]').val(data.uemail);
            $('[name="upassword"]').val(data.upassword);
            $('[name="urole"]').val(data.urole);
            $('[name="udept"]').val(data.udept);
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit User Details'); // Set title to Bootstrap modal title
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }
    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('index.php/user/user_add')?>";
      }
      else
        {
          url = "<?php echo site_url('index.php/user/user_update')?>";
        }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error in adding / update data');
            }
        });
    }
    function delete_user(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/user/user_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });
      }
    }
  </script>
  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">User Form</h3>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="uid"/>
          <div class="form-body">

            <div class="form-group">
              <label class="control-label col-md-3">User First Name</label>
              <div class="col-md-9">
                <input name="ufname" placeholder="User First Name" class="form-control" type="text">
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-3">User Last Name</label>
              <div class="col-md-9">
                <input name="ulname" placeholder="User Last Name" class="form-control" type="text">
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-3">User E-mail-Id</label>
              <div class="col-md-9">
                <input name="uemail" placeholder="User E-mail-Id" class="form-control" type="text">
              </div>
            </div>

            <div class="form-group">
							<label class="control-label col-md-3">User Password</label>
							<div class="col-md-9">
								<input name="upassword" placeholder="User Password" class="form-control" type="text">
							</div>
						</div>

            <div class="form-group">
							<label class="control-label col-md-3">Role</label>
							<div class="col-md-9">
                <select name="urole"  class="form-control">
 <option value="employee">Employee</option>
 <option value="manager">Manager</option>
</select>
								<!--<input name="urole" placeholder="Role" type="text">-->
							</div>
						</div>

            <div class="form-group">
							<label class="control-label col-md-3">Department</label>
							<div class="col-md-9">
								<input name="udept" placeholder="Department" class="form-control" type="text">
							</div>
						</div>

          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
  </body>
</html>
