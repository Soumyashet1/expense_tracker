<div class="container">
<h1>EXPENSES</h1>
</center>
  <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Travel Id</th>
        <th>Travel name</th>
        <th>EMPLOYEES(ID)</th>
        <th>START DATE</th>
        <th>END DATE</th>
        <th>LINKS</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($data1 as $usr){?>
           <tr>
               <td><?php echo $usr->tid;?></td>
               <td><?php echo $usr->tname;?> </td>
                <td><?php echo $usr->uid;?> </td>
                <td><?php echo $usr->tstartd;?> </td>
                <td><?php echo $usr->tendd;?> </td>
               <td><a href="<?php echo base_url ('/index.php/admin/each_t_expense/'.$usr->tid.'')?>">ALL </a>
                 <a href="<?php echo base_url ('/index.php/admin/each_t_expense_pending/'.$usr->tid.'')?>">PENDING </a>
                 <a href="<?php echo base_url ('/index.php/admin/each_t_expense_accepted/'.$usr->tid.'')?>">ACCEPTED</a>
                 <a href="<?php echo base_url ('/index.php/admin/each_t_expense_rejected/'.$usr->tid.'')?>">REJECTED</a>
               </td>
               <td><?php echo $usr->price;?></td>
            </tr>
           <?php }?>
    </tbody>
  </table>
</div>
</body>
</html>
