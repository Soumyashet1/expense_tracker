<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Expense extends CI_Controller {
public function __construct()
{
 		parent::__construct();
		$this->load->model('expense_model');
}
public function index() //shows all travel links of a particular user
{
    $data1['data1']= $this->expense_model->get_by_userid();
    $this->load->view('userheader');
		$this->load->view('user_view',$data1);
}
public function userexpense($td) //shows travel expenses of a particular travel of a user
{
    $data1['data1']= $this->expense_model->get_by_uid_tid($td);
    $this->load->view('userheader');
		$this->load->view('userexpense',$data1);
}
public function expense_add($td)
{
			$data = array(
        'uid' => $_SESSION['uid'],
        'tid' => $td,
        'exname' => $this->input->post('exname'),
        'exdate' => $this->input->post('exdate'),
        'exprice' => $this->input->post('exprice'),
        'exattach' => $this->input->post('exattach'),
				);
			$insert = $this->expense_model->expense_add($data);
			echo json_encode(array("status" => TRUE));
}
public function ajax_edit($id)
{
			$data = $this->expense_model->get_by_id($id);
			echo json_encode($data);
}
public function expense_update()
{
		$data = array(
      'uid' =>$_SESSION['uid'],
      'tid' => $this->input->post('tid'),
      'exname' => $this->input->post('exname'),
      'exdate' => $this->input->post('exdate'),
      'exprice' => $this->input->post('exprice'),
      'exattach' => $this->input->post('exattach'),
      );
		$this->expense_model->expense_update(array('exid' => $this->input->post('exid')), $data);
		echo json_encode(array("status" => TRUE));
}
public function expense_delete($id)
{
		$this->expense_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

}
