<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Travel extends CI_Controller {
public function __construct()
{
 		parent::__construct();
		$this->load->model('travel_model');
}
public function index()//shows all travels list
{
		$data['travel']=$this->travel_model->get_all_travels();
    $this->load->view('adminheader');
		$this->load->view('travel_view',$data);
}
public function travel_add()//adding new travel
{		$data = array(
					'uid' => $this->input->post('uid'),
					'tname' => $this->input->post('tname'),
					'tdesc' => $this->input->post('tdesc'),
					'tstartd' => $this->input->post('tsd'),
					'tendd' => $this->input->post('ted'),
					'status' => 'ongoing',
				);
			$insert = $this->travel_model->travel_add($data);//adding new travel
      echo json_encode(array("status" => TRUE));
      $tid=$this->travel_model->get_tid();//get latest tid
      $data = array(
					'uid' => $this->input->post('uid'),
          'tid' =>$tid,
					'exprice' =>'0',
					);
          $insert = $this->travel_model->exp_dummi_add($data);//add dummi value to expense table
}
public function ajax_edit($id)//edit travel details
{
			$data = $this->travel_model->get_by_id($id);
			echo json_encode($data);
}
public function travel_update()//edit travel details
{
		$data = array(
			'uid' => $this->input->post('uid'),
			'tname' => $this->input->post('tname'),
			'tdesc' => $this->input->post('tdesc'),
			'tstartd' => $this->input->post('tsd'),
			'tendd' => $this->input->post('ted'),
			'status' => $this->input->post('status'),
			);
		$this->travel_model->travel_update(array('tid' => $this->input->post('tid')), $data);
		echo json_encode(array("status" => TRUE));
}
public function travel_delete($id)//delete a travel details
{
		$this->travel_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
}
