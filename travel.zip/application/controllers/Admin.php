<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {
public function __construct()
{
	 		parent::__construct();
			$this->load->model('admin_model');
}
public function index() //shows all travels link wit price
{
	   $data1['data1'] = $this->admin_model->get_by_userid();
	    $this->load->view('adminheader');
			$this->load->view('admin_views',$data1);
}
public function each_t_expense($td) //shows travel expenses of a particular travel
{
	    $data1['data1']= $this->admin_model->get_by_tid($td);
	    $this->load->view('adminheader');
			$this->load->view('each_t_expenselist',$data1);
}
public function each_t_expense_pending($td) //shows travel expenses of a particular travel (pending requests)
{
		    $data1['data1']= $this->admin_model->get_by_tid_pend($td);
		    $this->load->view('adminheader');
				$this->load->view('each_t_expenselist',$data1);
}
public function each_t_expense_accepted($td) //shows travel expenses of a particular travel (accepted requests)
{
			    $data1['data1']= $this->admin_model->get_by_tid_acc($td);
			    $this->load->view('adminheader');
					$this->load->view('each_t_expenselist',$data1);
}
public function each_t_expense_rejected($td) //shows travel expenses of a particular travel (rejected requests)
{
				    $data1['data1']= $this->admin_model->get_by_tid_rej($td);
				    $this->load->view('adminheader');
						$this->load->view('each_t_expenselist',$data1);
}
public function edit_exp_accepted($e)//edits status of a particular expense
{
		$exid = $this->input->post('exid');
		 $data = array(
			 'exstatus' =>'accepted',
			);
			$this->admin_model->status_update(array('exid' =>$e ), $data);
			echo json_encode(array("status" => TRUE));
}
public function edit_exp_rejected($e)//edits status of a particular expense
{
			$exid = $this->input->post('exid');
			 $data = array(
				 'exstatus' =>'rejected',
				);
				$this->admin_model->status_update(array('exid' =>$e ), $data);
				echo json_encode(array("status" => TRUE));
}
}
