<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
public function __construct()
{
 		parent::__construct();
		$this->load->model('user_model');
}
public function index()
{
		$data['user']=$this->user_model->get_all_users();
    $this->load->view('adminheader');
		$this->load->view('users',$data);
}
public function user_add()
{
			$data = array(
					'ufname' => $this->input->post('ufname'),
					'ulname' => $this->input->post('ulname'),
					'uemail' => $this->input->post('uemail'),
					'upassword' => $this->input->post('upassword'),
					'urole' => $this->input->post('urole'),
					'udept' => $this->input->post('udept'),
				);
			$insert = $this->user_model->user_add($data);
			echo json_encode(array("status" => TRUE));
}
public function ajax_edit($id)
{
			$data = $this->user_model->get_by_id($id);
			echo json_encode($data);
}
public function user_update()
{
		$data = array(
      'ufname' => $this->input->post('ufname'),
      'ulname' => $this->input->post('ulname'),
      'uemail' => $this->input->post('uemail'),
      'upassword' => $this->input->post('upassword'),
      'urole' => $this->input->post('urole'),
      'udept' => $this->input->post('udept'),
			);
		$this->user_model->user_update(array('uid' => $this->input->post('uid')), $data);
		echo json_encode(array("status" => TRUE));
}
public function user_delete($id)
{
		$this->user_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
}
