<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
public function __construct()
{
        parent::__construct();
        $this->load->model('Login_model');
}
public function index()
{
		$this->load->view('main');//main page
}
public function loginpage()
{
         //get values of login page
        $email = $this->input->post("email");
        $password = $this->input->post("pass");
        //rules of form validation
        $this->form_validation->set_rules("email", "Email-ID", "trim|required");
        $this->form_validation->set_rules("pass", "Password", "required");
        if ($this->form_validation->run() == FALSE) //load the page if rules fails
        {
           $this->load->view('login');
        }
        else
        {
            // check for user credentials
            $uresult = $this->Login_model->get_user($email, $password);
			      echo $uresult;
            if (count($uresult) > 0)
            {
                // set session
                $sess_data = array('login' => TRUE, 'uname' => $uresult[0]->ufname, 'uid' => $uresult[0]->uid);
                $this->session->set_userdata($sess_data);
                if ( $uresult[0]->urole == "employee")// if Login credentials are of employees den redirect to expense controller
                {
                  redirect("/index.php/expense");
                }
                else {
                  redirect("/index.php/admin");//else redirect to admin controller
                }
            }
            else
            {
                redirect('/index.php/login/loginpage');//load the  same page if credentials r wrong
            }
        }
}
public function logout()
{
   // destroy session
  			 $data = array('login' => '', 'uname' => '', 'uid' => '');
  			 $this->session->unset_userdata($data);
  			 $this->session->sess_destroy();
         redirect('/index.php/Login');
  }
}
