<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Travel_model extends CI_Model
{
	var $table = 'travel';
	public function __construct()
	{
		parent::__construct();
	}
public function get_all_travels()//shows all travels list
{
$this->db->from('travel');
$query=$this->db->get();
return $query->result();
}
public function get_by_id($id)
{
		$this->db->from($this->table);
		$this->db->where('tid',$id);
		$query = $this->db->get();
		return $query->row();
}
public function travel_add($data)//adding new travel
{
		$this->db->insert($this->table, $data);
				return $this->db->insert_id();
}
public function get_tid()//get latest tid
{
			$query = $this->db->query("SELECT tid FROM travel ORDER BY tid DESC LIMIT 1");
			$res=$query->row()->tid;
			return $res;
}
public function exp_dummi_add($data)//add dummi value to expense table
{
		$this->db->insert('expense', $data);
				return $this->db->insert_id();
}
public function travel_update($where, $data)
{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
}
public function delete_by_id($id)
{
		$this->db->where('tid', $id);
		$this->db->delete($this->table);
}
}
