<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Expense_model extends CI_Model
{
	var $table = 'expense';
	public function __construct()
	{
		parent::__construct();
	}
public function get_by_id($id)//fetch oly details of a particular expense
{
		$this->db->from($this->table);
		$this->db->where('exid',$id);
		$query = $this->db->get();
		return $query->row();
}
public function get_by_uid_tid($td)//shows all travel expenses  of a particular user & particular travel...
{
	  $d1=$_SESSION['uid'];
		$query = $this->db->query("SELECT * FROM  expense  WHERE uid='$d1' AND tid='$td' ;");
		return $query->result();
}
public function get_by_userid()//shows all travels of a particular user
{
	 $d1=$_SESSION['uid'];
		$query = $this->db->query("SELECT t.tid,t.tname,sum(e.exprice) as price FROM  travel t,expense e WHERE e.uid='$d1' AND t.tid=e.tid GROUP BY e.tid;");
		return $query->result();
}
	public function expense_add($data)//adding new expense
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}
	public function expense_update($where, $data)//updating expenses
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}
	public function delete_by_id($id)//delete expenses
	{
		$this->db->where('exid', $id);
		$this->db->delete($this->table);
	}
	public function get_all_expenses()
	 {
	$this->db->from('expense');
	$query=$this->db->get();
	return $query->result();
	}
	public function get_by_uid()
	{
		  $d1=$_SESSION['uid'];
		  //echo $d1;
			$this->db->from($this->table);
			$this->db->where('uid',$d1);
			$query = $this->db->get();
			return $query->result();
	}
}
