<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin_model extends CI_Model
{
	var $table = 'expense';
	public function __construct()
	{
		parent::__construct();
	}
public function get_all_expenses()
{
$this->db->from('expense');
$query=$this->db->get();
return $query->result();
}
public function get_by_id($id)
{
		$this->db->from($this->table);
		$this->db->where('exid',$id);
		$query = $this->db->get();
		return $query->row();
}

public function get_by_uid()
{
	  $d1=$_SESSION['uid'];
	  //echo $d1;
		$this->db->from($this->table);
		$this->db->where('uid',$d1);
		$query = $this->db->get();
		return $query->result();
}
public function get_by_tid($td)
{
		$query = $this->db->query("SELECT * FROM  expense  WHERE tid='$td' AND exprice > 0;");
		return $query->result();
}
public function get_by_tid_pend($td)
{
		$query = $this->db->query("SELECT * FROM  expense  WHERE tid='$td' AND exstatus='pending' AND exprice > 0;");
		return $query->result();
}
public function get_by_tid_acc($td)
{
		$query = $this->db->query("SELECT * FROM  expense  WHERE tid='$td' AND exstatus='accepted' AND exprice > 0;");
		return $query->result();
}
public function get_by_tid_rej($td)
{
		$query = $this->db->query("SELECT * FROM  expense  WHERE tid='$td' AND exstatus='rejected' AND exprice > 0;");
		return $query->result();
}
public function get_by_userid()//shows all travels wit price
{
		$query = $this->db->query("SELECT t.tid,t.tname,t.uid,t.tstartd,t.tendd,sum(e.exprice) as price FROM  travel t,expense e WHERE t.tid=e.tid GROUP BY e.tid;");
		return $query->result();
}
	public function expense_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}
	public function expense_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}
	public function status_update($where,$data)
	{
		$this->db->update($this->table, $data,$where);
		return $this->db->affected_rows();
	}
	public function delete_by_id($id)
	{
		$this->db->where('exid', $id);
		$this->db->delete($this->table);
	}
}
