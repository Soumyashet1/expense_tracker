<?php
class Login_model extends CI_Model {
public function __construct()
{
         parent::__construct();
}
public function get_user($email, $pwd)
{
		$this->db->where('uemail', $email);
		$this->db->where('upassword',($pwd));
    $query = $this->db->get('user');
		return $query->result();
	}
 }
?>
